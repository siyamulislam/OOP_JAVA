package ab10;

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class ExHandle {

    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        int a = sc.nextInt();
//        int b = sc.nextInt();
//        int div; 
        
        
        
        try{
//           div = a / b;
//        System.out.println(div);
            String s= "abc";
        int i= Integer.parseInt(s);
                
        }catch(Exception e){
            System.out.println(e);
        }
        finally{
        System.out.println("Invalid entry ");
        }
        
    }

}
